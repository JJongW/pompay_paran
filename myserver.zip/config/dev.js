module.exports={
    mongoURI:'mongodb+srv://pompay:Ajouparan12!@cluster0.nhyqwb9.mongodb.net/?retryWrites=true&w=majority'
}